(function(root){
  'use strict';
  const KEYS=['inteligencia','perspicacia','romanticismo','empatia','creatividad','valentia'];
  const LEGACY_KEYS=KEYS.slice(0,3);
  const own=(object,key)=>Object.prototype.hasOwnProperty.call(object,key);
  const zero=()=>Object.fromEntries(KEYS.map(k=>[k,0]));
  function uid(){return root.crypto?.randomUUID?.() || 'local-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);}
  function story(id){return root.STORIES.find(s=>s.id===id);}
  function makeSession(caseId,people,mode='duo'){
    const s=story(caseId);if(!s)throw new Error('Caso no disponible.');
    if(!people.length||people.length>2)throw new Error('Elige uno o dos perfiles.');
    return {id:uid(),caseId,ownerId:people[0].userId,mode,status:mode==='duo'&&people.length<2?'waiting':'active',nodeId:s.startNode,version:0,createdAt:new Date().toISOString(),members:people.map((p,i)=>({...p,role:i?'B':'A',scores:zero()})),votes:[],history:[],firstVotes:{},firstVoteEffects:{},inviteActive:false};
  }
  function vote(session,userId,nodeId,choiceId,version){
    const s=story(session.caseId), n=s.nodes[session.nodeId];
    if(session.status!=='active')throw new Error('La partida todavía no está activa.');
    if(session.nodeId!==nodeId||session.version!==version)throw new Error('La partida ha avanzado. Revisa la nueva escena.');
    if(!session.members.some(m=>m.userId===userId))throw new Error('Este perfil no participa en la partida.');
    const choice=n?.choices.find(c=>c.id===choiceId);if(!choice)throw new Error('Elección no válida.');
    const next=structuredClone(session);next.firstVotes ||= {};next.firstVoteEffects ||= {};
    if(!own(next.firstVotes,userId)){
      next.firstVotes[userId]=choiceId;
      next.firstVoteEffects[userId]=structuredClone(choice.effects||{});
    }
    // Pending votes saved before effect snapshots existed can only earn legacy points.
    next.members.forEach(m=>{
      if(own(next.firstVotes,m.userId)&&!own(next.firstVoteEffects,m.userId)){
        const first=n.choices.find(c=>c.id===next.firstVotes[m.userId]);
        next.firstVoteEffects[m.userId]=Object.fromEntries(LEGACY_KEYS.map(k=>[k,first?.effects?.[k]||0]));
      }
    });
    next.votes=next.votes.filter(v=>v.userId!==userId);next.votes.push({userId,choiceId,nodeId});
    const agreed=next.members.every(m=>next.votes.some(v=>v.userId===m.userId&&v.choiceId===choiceId));
    if(agreed){
      const preferences={},preferenceEffects={};
      next.members.forEach(m=>{
        preferences[m.userId]=next.firstVotes[m.userId];
        preferenceEffects[m.userId]=structuredClone(next.firstVoteEffects[m.userId]);
        m.scores ||= {};
        KEYS.forEach(k=>m.scores[k]=(m.scores[k]||0)+(preferenceEffects[m.userId]?.[k]||0));
      });
      next.history.push({version:next.version,nodeId,choiceId,nextNodeId:choice.next,effects:structuredClone(choice.effects||{}),preferences,preferenceEffects,createdAt:new Date().toISOString()});
      next.nodeId=choice.next;next.version++;next.votes=[];next.firstVotes={};next.firstVoteEffects={};next.status=s.endings[next.nodeId]?'finished':'active';
    }
    next.updatedAt=new Date().toISOString();return {session:next,transitioned:agreed};
  }
  function totals(sessions,userId){const value=zero();let decisions=0,finished=0;const endings=new Set();sessions.forEach(s=>{const m=s.members.find(m=>m.userId===userId);if(!m)return;KEYS.forEach(k=>value[k]+=m.scores?.[k]||0);decisions+=s.history?.length||0;if(s.status==='finished'){finished++;endings.add(s.caseId+':'+s.nodeId);}});return {...value,decisions,finished,endings:endings.size};}
  root.GameEngine={KEYS,zero,uid,makeSession,vote,totals};if(typeof module!=='undefined')module.exports=root.GameEngine;
})(globalThis);
