(function (root) {
  'use strict';
  const own = (value, key) => value != null && Object.prototype.hasOwnProperty.call(value, key);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const list = value => Array.isArray(value) ? value : [];
  function catalog(cases) { return (Array.isArray(cases) ? cases : Object.values(cases || {})).filter(item => item && typeof item.id === 'string'); }
  function completed(sessions, userId) {
    if (typeof userId !== 'string' || !userId) return [];
    return list(sessions).filter(session => session?.status === 'finished' && list(session.members).some(member => member?.userId === userId));
  }
  function endings(story) {
    if (story?.endings && typeof story.endings === 'object') return Object.values(story.endings).filter(Boolean);
    return Object.values(story?.nodes || {}).filter(node => node?.terminal);
  }
  function endingFor(story, session) { return endings(story).find(ending => ending.id === session?.nodeId); }
  function dateLabel(session) {
    const raw = session?.updatedAt || session?.createdAt;
    const date = typeof raw === 'string' ? new Date(raw) : null;
    return date && Number.isFinite(date.getTime()) ? new Intl.DateTimeFormat('es-ES', {day:'numeric',month:'long',year:'numeric',timeZone:'UTC'}).format(date) : 'Fecha no disponible';
  }
  function historyView(story, session) {
    const members = list(session.members);
    const duo = (session.mode === 'duo' || session.mode == null) && members.length === 2 && members.every(member => typeof member?.userId === 'string' && member.userId) && members[0].userId !== members[1].userId;
    return list(session.history).map(entry => {
      const node = own(story?.nodes,entry?.nodeId) ? story.nodes[entry.nodeId] : null;
      const choices = list(node?.choices);
      const agreed = choices.find(choice => choice?.id === entry?.choiceId);
      const preferences = entry?.preferences;
      const verified = duo && agreed && members.every(member => own(preferences,member.userId) && choices.some(choice => choice?.id === preferences[member.userId]));
      return {
        title: agreed ? node.title || 'Una escena de vuestra historia' : 'Decisión guardada',
        choice: agreed ? agreed.label || 'Camino acordado' : 'El detalle de esta escena ya no está disponible.',
        comparison: verified ? (preferences[members[0].userId] === preferences[members[1].userId] ? 'Acordamos desde la primera elección' : 'Partimos de opciones distintas') : null,
        different: Boolean(verified && preferences[members[0].userId] !== preferences[members[1].userId]),
        verified: Boolean(verified), duo
      };
    });
  }
  function context(args = {}) {
    const sessions = completed(args.sessions,args.userId);
    const session = sessions.find(item => typeof args.sessionId === 'string' && item.id === args.sessionId);
    const story = session && catalog(args.cases).find(item => item.id === session.caseId);
    return {sessions,session,story,ending:endingFor(story,session)};
  }
  function routeHTML(route, compare) {
    if (!route.length) return '<p class="archive-note">Esta partida no conserva el detalle de sus decisiones.</p>';
    return '<ol class="archive-route">' + route.map(item => '<li><h3>' + esc(item.title) + '</h3><p>' + esc(item.choice) + '</p>' + (compare && item.duo ? '<small class="archive-agreement">' + esc(item.comparison || 'No se guardaron preferencias suficientes para comparar esta decisión.') + '</small>' : '') + '</li>').join('') + '</ol>';
  }
  function endingHTML(ending) {
    if (!ending) return '';
    const paragraphs = list(ending.text).filter(text => typeof text === 'string').map(text => '<p>' + esc(text) + '</p>').join('');
    const reflection = typeof ending.reflection === 'string' && ending.reflection ? '<p class="archive-reflection"><em>' + esc(ending.reflection) + '</em></p>' : '';
    return paragraphs || reflection ? '<div class="archive-ending-text">' + paragraphs + reflection + '</div>' : '';
  }
  function questions(route, ending) {
    const divergent = route.find(item => item.different);
    const matched = route.find(item => item.verified && !item.different);
    return [
      divergent ? 'En «' + divergent.title + '» partisteis de opciones distintas. ¿Qué argumento os ayudó a elegir un camino común?' : matched ? 'En «' + matched.title + '» coincidisteis al elegir. ¿Os llevó la misma pista a esa decisión?' : '¿Qué prueba cambió más vuestra forma de entender lo ocurrido?',
      'En «' + (ending?.title || 'vuestro desenlace') + '», ¿qué consecuencia os parece más importante para los personajes?',
      'Si volvierais a empezar, ¿qué decisión probaríais de otra manera y por qué?'
    ];
  }
  function render(args = {}) {
    const mine = completed(args.sessions,args.userId);
    const stories = catalog(args.cases);
    const knownSessions = mine.filter(session => stories.some(story => story.id === session.caseId));
    const startedIds = new Set(list(args.sessions).filter(session => list(session.members).some(member => member?.userId === args.userId)).map(session => session.caseId));
    const startedStories = stories.filter(story => startedIds.has(story.id));
    const seals = (startedStories.length ? startedStories : stories.slice(0,1)).map(story => {
      const known = new Set(mine.filter(session => session.caseId === story.id).map(session => session.nodeId));
      const all = endings(story);
      const discovered = all.filter(ending => known.has(ending.id));
      return '<section class="archive-case"><div class="archive-case-heading"><div><span class="eyebrow sage">LAS HUELLAS QUE HABÉIS DEJADO</span><h2>' + esc(story.title || 'Vuestra historia') + '</h2></div><p>' + discovered.length + ' de ' + all.length + ' finales descubiertos</p></div><div class="archive-seals">' + all.map((ending,index) => {
        const unlocked = known.has(ending.id);
        return '<article class="archive-seal ' + (unlocked ? 'discovered' : 'undiscovered') + '"><span class="archive-seal-number" aria-hidden="true">' + String(index+1).padStart(2,'0') + '</span><span class="archive-seal-status">' + (unlocked ? 'DESCUBIERTO' : 'POR DESCUBRIR') + '</span><h3>' + (unlocked ? esc(ending.title || 'Final descubierto') : 'Una historia aún cerrada') + '</h3><p>' + (unlocked ? 'Forma parte de vuestro archivo.' : 'Su título y su desenlace esperan a vuestra próxima partida.') + '</p></article>';
      }).join('') + '</div></section>';
    }).join('');
    const sessionsHTML = knownSessions.length ? '<section class="archive-sessions"><h2>Noches para recordar.</h2>' + knownSessions.map(session => {
      const story = stories.find(item => item.id === session.caseId), ending = endingFor(story,session);
      return '<article class="archive-session"><div><span class="eyebrow sage">' + esc(dateLabel(session)) + '</span><h3>' + esc(story.title || 'Vuestra historia') + '</h3><p>' + esc(ending?.title || 'Partida terminada') + '</p></div><div class="actions"><button type="button" class="button" data-action="archive-open" data-id="' + esc(session.id) + '">Abrir recuerdo</button><button type="button" class="text-button" data-action="archive-download" data-id="' + esc(session.id) + '">Guardar recuerdo</button></div></article>';
    }).join('') + '</section>' : '<section class="archive-empty"><h2>La primera noche todavía está por escribir.</h2><p>Cuando termines una partida, su recorrido y su desenlace aparecerán aquí. Cada nueva partida conserva las anteriores.</p><button type="button" class="button primary" data-action="setup">Empezar una historia</button></section>';
    return '<div class="night-archive"><header class="title-row archive-heading"><span class="eyebrow sage">VUESTRO ARCHIVO DE CAMINOS</span><h1>La noche termina.<br><em>La historia se queda.</em></h1><p>Volved a los caminos que habéis elegido y descubrid qué os queda por explorar. Los finales desconocidos mantienen su secreto.</p></header>' + seals + sessionsHTML + '</div>';
  }
  function renderSession(args = {}) {
    const {session,story,ending} = context(args);
    if (!session || !story) return '<div class="archive-memory"><h2 id="modal-title">Este recuerdo no está disponible.</h2><p>El archivo muestra únicamente tus partidas terminadas.</p></div>';
    const route = historyView(story,session);
    const duo = route.some(item => item.duo);
    return '<div class="archive-memory"><span class="eyebrow sage">UNA NOCHE PARA RECORDAR · ' + esc(dateLabel(session)) + '</span><h2 id="modal-title">' + esc(story.title || 'Vuestra historia') + '</h2><p class="archive-ending">' + esc(ending?.title || 'Partida terminada') + '</p>' + endingHTML(ending) + '<h3>El camino que elegimos.</h3>' + routeHTML(route,true) + '<section class="archive-epilogue"><span class="eyebrow sage">' + (duo ? 'EPÍLOGO DÚO' : 'UNA ÚLTIMA MIRADA') + '</span><h3>Después de cerrar el caso.</h3><p>Estas preguntas son una invitación a conversar, no una evaluación de vuestra relación ni de vuestra personalidad.</p><ol>' + questions(route,ending).map(question => '<li>' + esc(question) + '</li>').join('') + '</ol></section><div class="actions"><button type="button" class="button" data-action="archive-download" data-id="' + esc(session.id) + '">Guardar este recuerdo</button><button type="button" class="button primary" data-action="setup" data-case="' + esc(story.id) + '">Explorar otro camino</button></div></div>';
  }
  function exportSession(args = {}) {
    const {session,story,ending} = context(args);
    if (!session || !story) return null;
    const title = story.title || 'Vuestra historia';
    const route = historyView(story,session);
    const slug = String(title).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,60) || 'historia';
    const html = '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'"><title>Recuerdo · ' + esc(title) + '</title><style>body{margin:0;background:#171b1b;color:#f2eee5;font:17px/1.65 Georgia,serif}main{max-width:760px;margin:auto;padding:56px 24px}small,header p{color:#c6bba4}h1{font-size:clamp(36px,7vw,64px);line-height:1.1}h2{font-size:28px}h3{font-size:20px;margin-bottom:6px}.archive-route{padding-left:24px}.archive-route li{padding:12px 0;border-bottom:1px solid #665b4b}.archive-route p{margin-top:0}footer{margin-top:40px;border-top:1px solid #665b4b;padding-top:20px;font-size:14px} @media print{body{background:white;color:#171b1b}main{padding:12px}small,header p{color:#4e514a}}</style></head><body><main><header><small>LA ÚLTIMA PIEZA · UNA NOCHE PARA RECORDAR</small><h1>' + esc(title) + '</h1><p>' + esc(dateLabel(session)) + '</p></header><section><h2>' + esc(ending?.title || 'Partida terminada') + '</h2>' + endingHTML(ending) + '<h3>El camino que elegimos.</h3><p>Estas son las decisiones acordadas dentro de la historia.</p>' + routeHTML(route,false) + '</section><footer>Un recuerdo de esta partida terminada. Conserva las decisiones acordadas; no incluye preferencias individuales ni datos de acceso.</footer></main></body></html>';
    return {filename:'recuerdo-'+slug+'.html',html};
  }
  root.NightArchive = {render,renderSession,exportSession};
  if (typeof module !== 'undefined' && module.exports) module.exports = root.NightArchive;
})(globalThis);
