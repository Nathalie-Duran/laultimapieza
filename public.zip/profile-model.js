(function (root) {
  'use strict';

  const SKILLS = Object.freeze([
    { key: 'inteligencia', label: 'Inteligencia', icon: '◇', description: 'Conectar pruebas y buscar coherencia' },
    { key: 'perspicacia', label: 'Perspicacia', icon: '◎', description: 'Detectar detalles e intenciones' },
    { key: 'romanticismo', label: 'Romanticismo', icon: '♡', description: 'Cuidar recuerdos y vínculos en la historia' },
    { key: 'empatia', label: 'Empatía', icon: '◉', description: 'Comprender lo que otros necesitan' },
    { key: 'creatividad', label: 'Creatividad', icon: '✧', description: 'Buscar alternativas menos obvias' },
    { key: 'valentia', label: 'Valentía', icon: '△', description: 'Actuar asumiendo consecuencias dentro de la ficción' }
  ].map(skill => Object.freeze(skill)));
  const KEYS = Object.freeze(SKILLS.map(skill => skill.key));
  const LEGACY_KEYS = ['inteligencia', 'perspicacia', 'romanticismo'];
  const THRESHOLDS = [0, 2, 6, 12, 24];
  const STAGES = ['Por descubrir', 'Primeras huellas', 'En desarrollo', 'Con oficio', 'Con sello propio'];
  const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
  const number = value => typeof value === 'number' && Number.isFinite(value) ? Math.max(0, value) : 0;
  const emptyPoints = () => Object.fromEntries(KEYS.map(key => [key, 0]));
  const list = values => values.length < 2 ? values.join('') : values.slice(0, -1).join(', ') + ' y ' + values[values.length - 1];

  // Progress measures accumulated story points within a stage, never personal ability.
  function skillProgress(value) {
    const points = number(value);
    let level = 0;
    while (level + 1 < THRESHOLDS.length && points >= THRESHOLDS[level + 1]) level++;
    const threshold = THRESHOLDS[level];
    const isMaxLevel = level === THRESHOLDS.length - 1;
    const nextThreshold = isMaxLevel ? null : THRESHOLDS[level + 1];
    return {
      points, level, stage: level === 0 && points > 0 ? 'Primeras decisiones' : STAGES[level], threshold, nextThreshold,
      remaining: isMaxLevel ? 0 : nextThreshold - points,
      progress: isMaxLevel ? 100 : Math.min(100, Math.round(100 * (points - threshold) / (nextThreshold - threshold))),
      isMaxLevel
    };
  }

  function signature(totals) {
    const highest = Math.max(...SKILLS.map(skill => totals[skill.key]));
    if (!highest) return {
      title: 'Tu sello está por descubrir',
      description: 'Todavía no hay un estilo escrito. Explora un caso: tus decisiones dejarán las primeras huellas.'
    };
    const leaders = SKILLS.filter(skill => totals[skill.key] === highest);
    if (leaders.length >= 3) return {
      title: 'Estilo versátil',
      description: 'Tus preferencias narrativas han repartido los puntos por igual entre ' + list(leaders.map(skill => skill.label.toLocaleLowerCase('es'))) + '.'
    };
    if (leaders.length === 2) {
      const titles = {
        'inteligencia+perspicacia': 'Razón e intuición',
        'inteligencia+romanticismo': 'Lógica y corazón',
        'perspicacia+romanticismo': 'Intuición y corazón'
      };
      return {
        title: titles[leaders.map(skill => skill.key).join('+')] || leaders[0].label + ' y ' + leaders[1].label.toLocaleLowerCase('es'),
        description: 'En tus elecciones conviven dos formas de mirar la historia: ' + leaders.map(skill => skill.label.toLocaleLowerCase('es')).join(' y ') + '.'
      };
    }
    const styles = {
      inteligencia: {
        title: 'Mente analítica',
        description: 'Tus elecciones han dado protagonismo a las pruebas y a la coherencia de la historia.'
      },
      perspicacia: {
        title: 'Mirada perspicaz',
        description: 'Tus elecciones han dado protagonismo a los detalles y a las intenciones de los personajes.'
      },
      romanticismo: {
        title: 'Instinto romántico',
        description: 'Tus elecciones han dado protagonismo a los recuerdos y a los vínculos de los personajes.'
      },
      empatia: {
        title: 'Mirada empática',
        description: 'Tus elecciones han dado protagonismo a comprender lo que necesitan los personajes.'
      },
      creatividad: {
        title: 'Mente creativa',
        description: 'Tus elecciones han dado protagonismo a buscar alternativas menos obvias dentro de la historia.'
      },
      valentia: {
        title: 'Espíritu decidido',
        description: 'Tus elecciones han dado protagonismo a actuar asumiendo consecuencias dentro de la ficción.'
      }
    };
    return { ...styles[leaders[0].key] };
  }

  function fromTotals(values) {
    const input = values || {};
    const totals = { ...emptyPoints(), decisions: 0, finished: 0, endings: 0 };
    Object.keys(totals).forEach(key => { totals[key] = number(input[key]); });
    return {
      totals,
      skills: SKILLS.map(skill => ({ ...skill, ...skillProgress(totals[skill.key]), evidence: [] })),
      signature: signature(totals),
      achievements: [
        { id: 'first-decision', title: 'La primera huella', description: 'Completa una decisión en una partida.', unlocked: totals.decisions >= 1 },
        { id: 'first-ending', title: 'Un caso hasta el final', description: 'Llega al final de una partida.', unlocked: totals.finished >= 1 },
        { id: 'two-endings', title: 'Otra forma de terminar', description: 'Descubre dos finales distintos en tus partidas.', unlocked: totals.endings >= 2 },
        { id: 'duo-ending', title: 'Un final entre dos', description: 'Termina una partida en pareja.', unlocked: false },
        { id: 'six-skills', title: 'Todas las miradas', description: 'Suma puntos narrativos en las seis habilidades.', unlocked: KEYS.every(key => totals[key] > 0) },
        { id: 'three-preferences', title: 'Una voz propia', description: 'Deja tres primeras preferencias personales verificadas en decisiones completadas.', unlocked: false }
      ],
      recent: [],
      hasDecisions: totals.decisions > 0
    };
  }

  function describe(sessions, userId, stories) {
    const totals = { ...emptyPoints(), decisions: 0, finished: 0, endings: 0 };
    const endings = new Set();
    const decisions = [];
    let finishedDuo = false;
    const catalog = Array.isArray(stories) ? stories : Object.values(stories || {});
    const byId = new Map(catalog.filter(Boolean).map(story => [story.id, story]));
    let order = 0;
    for (const session of Array.isArray(sessions) ? sessions : []) {
      const member = session?.members?.find(person => person.userId === userId);
      if (!member) continue;
      SKILLS.forEach(skill => { totals[skill.key] += number(member.scores?.[skill.key]); });
      const history = Array.isArray(session.history) ? session.history : [];
      totals.decisions += history.length;
      if (session.status === 'finished') {
        totals.finished++;
        endings.add(session.caseId + ':' + session.nodeId);
        const distinctMembers = new Set(session.members.map(person => person.userId));
        if (distinctMembers.size >= 2 && (session.mode === 'duo' || !session.mode)) finishedDuo = true;
      }
      const story = byId.get(session.caseId);
      for (const entry of history) {
        // Consensus can differ from this member's first preference. Never infer it.
        if (!entry?.preferences || !own(entry.preferences, userId)) continue;
        const node = story?.nodes?.[entry.nodeId];
        const choice = node?.choices?.find(option => option.id === entry.preferences[userId]);
        if (!choice) continue;
        const points = emptyPoints();
        const hasSnapshot = entry.preferenceEffects && own(entry.preferenceEffects, userId);
        if (hasSnapshot) {
          // Preserve the score recorded for this preference, even if the story changes.
          const snapshot = entry.preferenceEffects[userId];
          if (snapshot && typeof snapshot === 'object' && !Array.isArray(snapshot)) {
            KEYS.forEach(key => { if (own(snapshot, key)) points[key] = number(snapshot[key]); });
          }
        } else {
          // Older histories never recorded the new skills. Do not award them retroactively.
          LEGACY_KEYS.forEach(key => { points[key] = number(choice.effects?.[key]); });
        }
        const createdAt = typeof entry.createdAt === 'string' ? entry.createdAt : null;
        const timestamp = Date.parse(createdAt || '');
        decisions.push({
          caseTitle: story.title || session.caseId,
          nodeTitle: node.title || entry.nodeId,
          choiceLabel: choice.label || choice.id,
          points,
          sessionId: session.id,
          createdAt,
          version: Number.isInteger(entry.version) ? entry.version : null,
          timestamp: Number.isFinite(timestamp) ? timestamp : null,
          order: order++
        });
      }
    }
    totals.endings = endings.size;
    const model = fromTotals(totals);
    model.achievements.find(achievement => achievement.id === 'duo-ending').unlocked = finishedDuo;
    model.achievements.find(achievement => achievement.id === 'three-preferences').unlocked = decisions.length >= 3;
    // A fresh collection keeps the caller's sessions and histories unchanged.
    decisions.sort((a, b) => {
      if (a.timestamp !== null && b.timestamp !== null) return b.timestamp - a.timestamp || b.order - a.order;
      if (a.timestamp !== null) return -1;
      if (b.timestamp !== null) return 1;
      return b.order - a.order;
    });
    model.recent = decisions.map(({ timestamp, order, ...decision }) => decision);
    model.skills.forEach(skill => {
      skill.evidence = model.recent.filter(decision => decision.points[skill.key] > 0).map(decision => ({
        caseTitle: decision.caseTitle,
        nodeTitle: decision.nodeTitle,
        choiceLabel: decision.choiceLabel,
        points: decision.points[skill.key],
        sessionId: decision.sessionId
      }));
    });
    return model;
  }

  root.ProfileModel = { describe, fromTotals, skillProgress, SKILLS, KEYS };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.ProfileModel;
})(globalThis);
