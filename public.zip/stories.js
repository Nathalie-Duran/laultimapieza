(function (root) {
  'use strict';

  const STORIES = [
    {
      id: 'habitacion-309',
      title: 'La habitación 309',
      subtitle: 'La última noche del Bellamar',
      description: 'Una joya desaparece horas antes de una subasta. Dos investigadores, una carta sin enviar y una decisión: a quién pertenece una historia cuando todos quieren contarla.',
      duration: '15–25 min · duración orientativa',
      players: '2 jugadores · un equipo',
      tags: ['Misterio', 'Decisiones', 'Romance opcional'],
      setting: 'Hotel Bellamar · 21:18 · última noche antes del cierre',
      startNode: 'umbral',
      roles: {
        A: {
          name: 'Alex',
          title: 'La mirada narrativa',
          description: 'Periodista cultural. Tu dossier reúne palabras, correspondencia y testimonios. Cuenta a tu compañero lo que has encontrado: parte de la historia solo está en tus manos.'
        },
        B: {
          name: 'Noa',
          title: 'La mirada material',
          description: 'Especialista en conservación. Tu dossier reúne objetos, marcas y registros. Comparte los detalles: una frase puede significar otra cosa al lado de tu evidencia.'
        }
      },
      introduction: [
        'Alex y Noa son dos personajes adultos que ya han investigado juntos. Habéis llegado al Bellamar para documentar su última noche. A medianoche se subastarán varios objetos del hotel.',
        'Entre ellos figura la Luna de nácar: un colgante que perteneció a Elvira Soler, la pianista que actuó aquí durante veinte años. Ahora su estuche está vacío.',
        'Leed cada uno vuestro dossier y comparad lo que sabéis antes de decidir. No hace falta interpretar un papel ni fingir una relación. La cercanía entre Alex y Noa es una posibilidad de la ficción que podéis elegir o dejar fuera.'
      ],
      skillLabels: {
        inteligencia: 'Inteligencia',
        perspicacia: 'Perspicacia',
        romanticismo: 'Romanticismo',
        empatia: 'Empatía',
        creatividad: 'Creatividad',
        valentia: 'Valentía'
      },
      skillDisclaimer: 'Los puntos describen el estilo elegido para los personajes dentro del juego. No miden vuestra inteligencia, personalidad, relación ni capacidad romántica. Todas las rutas permiten resolver el misterio.',
      rules: [
        'Cada escena ofrece exactamente dos decisiones. Ambos jugadores deben acordar una.',
        'Los documentos presentados son auténticos dentro de esta historia ficticia. Las afirmaciones de los personajes pueden necesitar contraste.',
        'Las rutas cambian el destino de la joya y de la historia. No hay una respuesta romántica obligatoria ni una puntuación moral.'
      ],
      nodes: {
        umbral: {
          id: 'umbral',
          chapter: '01 · El estuche vacío',
          title: 'El mar se oye detrás de la puerta',
          text: [
            'La habitación 309 conserva las marcas claras de los cuadros que ya han descolgado. Sobre el escritorio hay un estuche de terciopelo vacío. La tarjeta de la subasta llama al colgante «propiedad histórica del Hotel Bellamar».',
            'Damián Roca, el director, os pide que lo encontréis antes de medianoche. «La pianista se lo vendió al hotel hace años», asegura. En el pasillo, una joven con una carpeta azul escucha la frase y se marcha hacia la terraza.',
            'Tenéis dos primeras pistas. El reverso de una fotografía apunta al archivo del hotel. Junto al estuche ha quedado una tarjeta de consigna con una breve nota. La subasta aún no ha empezado; podéis investigar sin correr.'
          ],
          evidence: {
            A: {
              title: 'Reverso de una fotografía',
              text: 'Elvira, junto al piano del vestíbulo. Detrás se lee: «Entrega temporal. Acuerdo de depósito, carpeta 309». La palabra temporal está subrayada. Debajo aparece el nombre de Elena Soler.'
            },
            B: {
              title: 'Tarjeta encontrada bajo el estuche',
              text: 'Consigna de seguridad · resguardo 6 · 21:08. Una nota manuscrita: «Vera. Si preguntan por la Luna, estaré en la terraza». No indica quién figura como propietario.'
            }
          },
          hint: 'Una pista puede aclarar de quién es el colgante; la otra, dónde ha ido. Elegid qué queréis averiguar primero.',
          choices: [
            {
              id: 'abrir-archivo',
              label: 'Buscar el acuerdo de depósito',
              description: 'Empezad por la historia documental de la joya y contrastad la versión del director.',
              next: 'archivo',
              effects: { inteligencia: 2, perspicacia: 0, romanticismo: 0, empatia: 0, creatividad: 1, valentia: 0 }
            },
            {
              id: 'seguir-terraza',
              label: 'Encontrar a Vera en la terraza',
              description: 'Seguid el rastro de la retirada y escuchad a quienes estaban allí.',
              next: 'terraza',
              effects: { inteligencia: 0, perspicacia: 2, romanticismo: 0, empatia: 1, creatividad: 0, valentia: 0 }
            }
          ]
        },
        archivo: {
          id: 'archivo',
          chapter: '02 · La historia escrita',
          title: 'Una compra que nunca ocurrió',
          text: [
            "La carpeta 309 contiene un acuerdo de 2006 y una factura de 1998. Alex recibe las copias del archivo; Noa accede a la edición del catálogo guardada esta mañana. Los años, por sí solos, no explican quién es dueño de la Luna: tendréis que leer lo que identifica cada documento.",
            "Abrid el PDF y buscad el lote 309 en la web del Bellamar. Comparad el concepto de la factura con el objeto del catálogo y consultad el historial de cambios. La versión del director depende de que esas referencias encajen.",
            "Elena llega al archivo. Es la nieta de Elvira y trae el documento que la identifica como heredera del colgante. Solo pide una cosa de momento: que la joya no se venda. En una funda aparte conserva una carta que su abuela nunca envió."
          ],
          evidence: {
            "A": {
              "title": "La carpeta que debe leer Alex",
              "text": "En el PDF están el acuerdo de depósito y la identificación de la factura original. Lee la cláusula de titularidad y el concepto de compra. Por separado, Elena muestra una adjudicación auténtica de la joya a su nombre como heredera: ser contacto de devolución no bastaría para acreditar su propiedad. Comparte los dos documentos con Noa."
            },
            "B": {
              "title": "La consulta que debe hacer Noa",
              "text": "Abre el archivo web del Bellamar y busca 309. Anota la referencia de compra, consulta el historial de esa ficha y vuelve a buscar por la referencia. Alex tiene el original que permite comprobar si el catálogo atribuye el documento al objeto correcto."
            }
          },
          hint: "El año de una factura no basta: fijaos en qué objeto se compró y qué campo cambió en el catálogo. La cláusula del depósito y la adjudicación de Elena explican dos momentos distintos de la propiedad.",
          choices: [
            {
              id: 'priorizar-restitucion',
              label: 'Preparar la devolución a Elena',
              description: 'Conservad las pruebas y centrad la siguiente decisión en la joya y la privacidad familiar.',
              next: 'resguardo',
              effects: { inteligencia: 1, perspicacia: 1, romanticismo: 0, empatia: 1, creatividad: 0, valentia: 0 }
            },
            {
              id: 'documentar-manipulacion',
              label: 'Impugnar el catálogo de la subasta',
              description: 'Preparad un expediente verificable. Esta ruta abordará la responsabilidad del hotel y el destino público de la historia.',
              next: 'catalogo',
              effects: { inteligencia: 2, perspicacia: 0, romanticismo: 0, empatia: 0, creatividad: 0, valentia: 1 }
            }
          ]
        },
        terraza: {
          id: 'terraza',
          chapter: '02 · La historia contada',
          title: 'Vera no está huyendo',
          text: [
            "Vera Núñez, la conservadora del hotel, espera sentada junto a una lámpara apagada. Elena está con ella. Sobre la mesa hay una autorización y un resguardo de consigna. «Antes de discutir lo que hice, comprobad lo que dejé registrado», dice Vera.",
            "Elena entrega a Alex el mensaje de voz que recibió esta noche. Noa obtiene una secuencia muda de la cámara de recepción. Escuchad o leed el mensaje y observad la secuencia: cada uno demuestra algo distinto, y ninguno sustituye todos los documentos.",
            "Elena acredita ser la heredera de la Luna con la adjudicación de la joya y el acuerdo de depósito de su abuela. Conserva también una carta personal de Elvira. Prefiere que separéis esa intimidad del problema de la subasta."
          ],
          evidence: {
            "A": {
              "title": "Un permiso y un mensaje de voz",
              "text": "Elena presenta una autorización firmada a las 21:00 para que Vera retire y custodie su colgante. Escucha el mensaje de Vera —o lee su transcripción— para averiguar qué afirma haber hecho después. Pide a Noa que contraste el lugar y la hora: una declaración necesita apoyo documental."
            },
            "B": {
              "title": "Una imagen no lo demuestra todo",
              "text": "El resguardo identifica como depositante a Vera Núñez. Su fotografía de entrada muestra una muesca a las cuatro en el colgante: coincide con la ficha de conservación. Observa en la cámara el compartimento y la hora, y contrástalos con el mensaje que tiene Alex. La silueta no identifica a una persona ni permite ver el interior del estuche. El precinto se comprueba intacto."
            }
          },
          hint: "Comparad tres cosas: lo que Vera dice en el mensaje, lo que se ve en la cámara y lo que acreditan el permiso y la fotografía del resguardo. No atribuyáis a una imagen muda más información de la que contiene.",
          choices: [
            {
              id: 'acompanar-elena',
              label: 'Acompañar a Elena a recuperar la joya',
              description: 'Priorizad su decisión y mantened la carta fuera del conflicto público.',
              next: 'resguardo',
              effects: { inteligencia: 0, perspicacia: 2, romanticismo: 0, empatia: 1, creatividad: 0, valentia: 0 }
            },
            {
              id: 'examinar-catalogo',
              label: 'Revisar cómo llegó al catálogo',
              description: 'Buscad la prueba documental de la maniobra antes de decidir cómo hacerla visible.',
              next: 'catalogo',
              effects: { inteligencia: 2, perspicacia: 0, romanticismo: 0, empatia: 0, creatividad: 1, valentia: 0 }
            }
          ]
        },
        resguardo: {
          id: 'resguardo',
          chapter: '03 · Lo que merece quedarse',
          title: 'La Luna está a salvo',
          text: [
            "En recepción reunís las pruebas de ambas rutas. Si habéis llegado desde el archivo, escuchad ahora el mensaje de Vera y revisad la cámara; si habéis pasado por la terraza, podéis contrastar el depósito y el catálogo. Elena acredita su propiedad con la adjudicación y aporta un permiso firmado a las 21:00 para que Vera retire y custodie la Luna. El resguardo identifica a Vera; la muesca de su fotografía coincide con la ficha de conservación y el precinto está intacto. Antes de seguir, acordad dónde está la Luna y por qué la retiraron.",
            "Elena permite que leáis una sola frase de la carta de Elvira a Inés, su compañera: «Nunca supe pedirte que te quedaras; por eso guardé un lugar para ti en cada canción». Después cierra la funda. El resto no forma parte de vuestra investigación.",
            "Hasta que la responsable de recepción termine el acta de retirada tenéis unos minutos. Alex mira hacia el mirador. Noa deja el cuaderno abierto por una página vacía. Podéis dar espacio a esa cercanía o concentraros en el trabajo; ninguna opción cambia las pruebas."
          ],
          evidence: {
            A: {
              title: 'La preferencia de Elena',
              text: '«No quiero que la carta se publique. Puedo llevarme la Luna a casa o destinar su venta a una beca de piano con el nombre de mi abuela. Me haría bien cualquiera de las dos cosas». Elena autoriza que preparéis una de esas rutas; cualquier venta necesitará su firma final.'
            },
            B: {
              title: 'Opciones de custodia comprobadas',
              text: 'La responsable de recepción ofrece un acta de devolución. La escuela municipal de música confirma que puede custodiar la pieza y organizar una venta benéfica posterior, separada de la subasta del hotel y aprobada por Elena. En ambos casos se conserva intacta la carta.'
            }
          },
          hint: 'La joya puede protegerse de dos maneras. Esta decisión intermedia solo elige cómo viven la pausa vuestros personajes.',
          choices: [
            {
              id: 'pausa-cercana',
              label: 'Compartir un momento en el mirador',
              description: 'Elegid una escena de cercanía romántica entre Alex y Noa. Es opcional y pertenece solo a la ficción.',
              next: 'mirador_privado',
              effects: { inteligencia: 0, perspicacia: 0, romanticismo: 2, empatia: 1, creatividad: 0, valentia: 0 }
            },
            {
              id: 'pausa-profesional',
              label: 'Preparar el acta juntos',
              description: 'Mantened el vínculo profesional y ordenad los detalles de la restitución.',
              next: 'mesa_privada',
              effects: { inteligencia: 1, perspicacia: 1, romanticismo: 0, empatia: 1, creatividad: 0, valentia: 0 }
            }
          ]
        },
        catalogo: {
          id: 'catalogo',
          chapter: '03 · El precio de una versión',
          title: 'La línea que Damián cambió',
          text: [
            "La subastadora necesita referencias comprobables. Si venís de la terraza, abrid ahora el PDF de la carpeta 309 y la ficha del catálogo, incluido su historial. Si venís del archivo, añadid el mensaje de Vera y la cámara de recepción. Alex y Noa deben contrastar lo que sabe cada uno antes de presentar su expediente.",
            "Elena aporta además su adjudicación de la joya y la autorización firmada para que Vera la custodiara. El resguardo identifica a Vera y muestra la misma muesca que la ficha de conservación; el precinto está intacto. La subastadora suspende ese lote mientras revisa los originales. Os pide preparar el siguiente paso: explicar qué documento se atribuyó al objeto equivocado y qué demuestra la retirada.",
            "Elena desea que se corrija la historia. Autoriza una reclamación formal. También aceptaría un préstamo para una exposición temporal si un acuerdo escrito reconoce su propiedad y mantiene privada la carta de Elvira. Mientras se prepara el acta, Alex y Noa tienen unos minutos a solas."
          ],
          evidence: {
            A: {
              title: 'Consentimiento de Elena',
              text: '«Podéis presentar los documentos para una reclamación. Si preferís la exposición, estoy dispuesta a prestar la Luna durante un mes. La carta personal no se mostrará». Ninguna alternativa autoriza su venta.'
            },
            B: {
              title: 'Dos compromisos por escrito',
              text: 'La subastadora ofrece remitir el expediente y precintar la pieza mientras se revisa la reclamación. El archivo municipal ofrece una exposición gratuita de un mes, con inventario, seguro, devolución a Elena y reconocimiento expreso de propiedad. Ambas ofertas están confirmadas.'
            }
          },
          hint: "Buscad por la referencia de la factura en la web, no solo por 309. Después separad autoría, propiedad y custodia: ningún archivo responde por sí solo a las tres preguntas. La siguiente decisión únicamente elige el tono entre los personajes.",
          choices: [
            {
              id: 'hablar-mirador',
              label: 'Dar un paso hacia la cercanía',
              description: 'Alex y Noa salen al mirador y hablan de lo que significa seguir eligiendo investigar juntos.',
              next: 'mirador_publico',
              effects: { inteligencia: 0, perspicacia: 0, romanticismo: 2, empatia: 0, creatividad: 0, valentia: 1 }
            },
            {
              id: 'cerrar-expediente',
              label: 'Seguir trabajando como equipo',
              description: 'Ordenad las pruebas y preparad la última decisión sin introducir romance.',
              next: 'mesa_publica',
              effects: { inteligencia: 1, perspicacia: 1, romanticismo: 0, empatia: 0, creatividad: 0, valentia: 1 }
            }
          ]
        },
        mirador_privado: {
          id: 'mirador_privado',
          chapter: '04 · Antes de marcharse',
          title: 'Una invitación que no necesita respuesta',
          text: [
            'Desde el mirador se ve el reflejo de una sola habitación encendida: la 309. Alex sonríe. «Cuando terminemos, me gustaría volver aquí contigo sin tener un caso pendiente». Noa se acerca y responde: «Podemos empezar por un café mañana». No hay una promesa mayor que esa.',
            'La responsable de recepción os llama. Elena espera con dos formularios. La Luna ya no corre peligro de ser vendida por el hotel. Podéis devolverla a la familia o preparar, con Elena, una venta benéfica posterior para financiar una beca de piano.',
            'Elena ha aceptado cualquiera de las dos opciones. Una conserva el objeto en casa; la otra lo transforma en una oportunidad musical. No es una decisión que podáis tomar sin ella.'
          ],
          evidence: {
            A: {
              title: 'Lo que Elena llevaría a casa',
              text: 'Su identidad y propiedad están verificadas. Puede firmar ahora la entrega de la Luna. La carta permanece cerrada en su carpeta y nadie conservará una copia.'
            },
            B: {
              title: 'Lo que podría convertirse en música',
              text: 'La escuela municipal acepta custodiar la Luna para una venta benéfica posterior. Elena supervisará la venta y firmará su aprobación. El dinero se destinará a una beca de piano con el nombre de Elvira; la carta no forma parte de la cesión.'
            }
          },
          hint: 'No hay un engaño oculto entre estas opciones. Una preserva el recuerdo material; la otra prolonga su historia mediante una beca. Elena ha consentido ambas.',
          choices: [
            {
              id: 'entrega-ahora-cercana',
              label: 'Devolver la Luna esta noche',
              description: 'Elena se lleva la joya y la carta. El cierre pertenece a la familia.',
              next: 'promesa_devuelta',
              effects: { inteligencia: 0, perspicacia: 2, romanticismo: 0, empatia: 1, creatividad: 0, valentia: 0 }
            },
            {
              id: 'custodia-manana-cercana',
              label: 'Preparar una beca con la Luna',
              description: 'Elena destinará una venta benéfica posterior a una beca de piano. La carta seguirá en casa.',
              next: 'buen_recaudo',
              effects: { inteligencia: 2, perspicacia: 0, romanticismo: 0, empatia: 0, creatividad: 1, valentia: 0 }
            }
          ]
        },
        mesa_privada: {
          id: 'mesa_privada',
          chapter: '04 · La última comprobación',
          title: 'Dos firmas, dos formas de cerrar',
          text: [
            'Alex prepara una relación de hechos. Noa verifica el número del precinto y la muesca del colgante. Trabajáis con la familiaridad de quienes saben cuándo hablar y cuándo dejar que el otro termine una idea.',
            'Elena agradece que no hayáis convertido la carta en una prueba pública. La responsable de recepción dispone el formulario de devolución. A su lado está la oferta de la escuela municipal: custodiar la Luna para organizar una venta benéfica posterior, supervisada por Elena.',
            'Podéis cerrar el expediente devolviendo un recuerdo a casa o preparando una beca de piano con el nombre de Elvira. Elena está dispuesta a elegir cualquiera de las dos rutas. La venta del hotel queda anulada en ambas.'
          ],
          evidence: {
            A: {
              title: 'Acta de entrega',
              text: 'Elena, identificada como propietaria, puede recibir la Luna ahora. Firma la recepción y conserva la carta personal. El hotel retiene únicamente el documento de devolución.'
            },
            B: {
              title: 'Acuerdo para una beca',
              text: 'La escuela custodiará la pieza hasta una venta benéfica futura aprobada por Elena. El acuerdo destina los fondos a una beca de piano con el nombre de Elvira. La carta queda expresamente fuera de la cesión.'
            }
          },
          hint: 'La investigación ya está completa. Esta elección decide entre conservar un objeto familiar y transformarlo, con permiso de Elena, en una oportunidad para otra persona.',
          choices: [
            {
              id: 'entrega-ahora-equipo',
              label: 'Entregar la joya a Elena ahora',
              description: 'Cerrad la noche con una restitución inmediata y privada.',
              next: 'promesa_devuelta',
              effects: { inteligencia: 0, perspicacia: 2, romanticismo: 0, empatia: 1, creatividad: 0, valentia: 0 }
            },
            {
              id: 'custodia-manana-equipo',
              label: 'Formalizar el proyecto de la beca',
              description: 'Preparad con Elena la custodia y la futura venta benéfica que financiará clases de piano.',
              next: 'buen_recaudo',
              effects: { inteligencia: 2, perspicacia: 0, romanticismo: 0, empatia: 0, creatividad: 1, valentia: 0 }
            }
          ]
        },
        mirador_publico: {
          id: 'mirador_publico',
          chapter: '04 · Una historia hacia fuera',
          title: 'La ciudad al otro lado del cristal',
          text: [
            'En el mirador, Noa pregunta qué recordará Alex del Bellamar. «Este minuto», responde. «No porque el caso haya salido bien. Porque has decidido quedarte a pensarlo conmigo». Alex ofrece una mano; Noa la toma. Es una escena de vuestros personajes, no una conclusión sobre quienes juegan.',
            'Al volver, la subastadora y la representante del archivo municipal esperan una respuesta. Podéis activar la reclamación sobre la manipulación del catálogo, o aceptar el préstamo documentado que Elena ofrece al archivo. En ninguno de los dos caminos se publicará la carta.',
            'Una opción prioriza la responsabilidad por lo sucedido. La otra convierte la recuperación en una historia pública que Elena ha elegido compartir. No cabe hacer ambas esta noche: el archivo debe confirmar ahora su espacio y la subastadora necesita cerrar el expediente de custodia.'
          ],
          evidence: {
            A: {
              title: 'El alcance del consentimiento',
              text: 'Elena aprueba tanto la reclamación como el préstamo temporal. Para la exposición autoriza contar la vida profesional de Elvira y mostrar el colgante; excluye expresamente la carta y la relación personal que revela.'
            },
            B: {
              title: 'Consecuencias previstas',
              text: 'Reclamación: pieza bajo custodia hasta revisión, registro de la alteración y Damián apartado del catálogo mientras se investiga. Exposición: un mes de préstamo al archivo, placa de propiedad de Elena y devolución acordada; no se inicia esa reclamación esta noche.'
            }
          },
          hint: 'Las dos opciones protegen la propiedad. Lo que cambia es la prioridad de la última acción: exigir responsabilidades o compartir un legado con consentimiento.',
          choices: [
            {
              id: 'reclamacion-cercana',
              label: 'Presentar la reclamación documentada',
              description: 'Entregad los originales y detened la maniobra del catálogo mediante una revisión formal.',
              next: 'subasta_cancelada',
              effects: { inteligencia: 2, perspicacia: 0, romanticismo: 0, empatia: 0, creatividad: 0, valentia: 1 }
            },
            {
              id: 'exposicion-cercana',
              label: 'Aceptar el préstamo al archivo',
              description: 'La Luna contará una historia pública durante un mes, con Elena como propietaria y la carta a salvo.',
              next: 'ultima_luz',
              effects: { inteligencia: 0, perspicacia: 2, romanticismo: 0, empatia: 0, creatividad: 1, valentia: 0 }
            }
          ]
        },
        mesa_publica: {
          id: 'mesa_publica',
          chapter: '04 · El destino del expediente',
          title: 'La prueba no decide por vosotros',
          text: [
            'Alex redacta una cronología sin adjetivos. Noa coloca junto a ella el depósito original, la factura del reloj y el historial del catálogo. Las piezas encajan. Vuestro trabajo como equipo ha separado un objeto de la historia interesada que alguien había escrito sobre él.',
            'La subastadora ofrece abrir una reclamación y custodiar la Luna mientras se revisa la alteración. La representante del archivo municipal propone un préstamo de un mes, autorizado por Elena, para mostrar la pieza como parte de la historia musical de la ciudad.',
            'Elena autoriza ambas rutas y mantiene privada la carta. Esta noche debéis elegir una: el archivo necesita confirmar el espacio y la subastadora cerrar el acta de custodia. Una prioriza responsabilidades; la otra, un legado compartido. La propiedad de Elena se respeta en las dos.'
          ],
          evidence: {
            A: {
              title: 'Qué puede hacerse público',
              text: 'El acuerdo de depósito, la atribución errónea y la carrera de Elvira pueden explicarse. La carta no puede reproducirse. Elena ha revisado esas condiciones antes de dar su consentimiento.'
            },
            B: {
              title: 'Dos actas pendientes de firma',
              text: 'Una remite el expediente de la manipulación y mantiene la pieza bajo custodia para la revisión. La otra documenta un préstamo de un mes al archivo, su seguro, su inventario y su devolución. No hay venta en ninguna.'
            }
          },
          hint: 'Una conclusión correcta puede abrir varias decisiones razonables. Elegid la consecuencia que queréis que tenga vuestro trabajo.',
          choices: [
            {
              id: 'reclamacion-equipo',
              label: 'Remitir el expediente para revisión',
              description: 'Priorizad la investigación de la manipulación y dejad constancia formal de lo ocurrido.',
              next: 'subasta_cancelada',
              effects: { inteligencia: 2, perspicacia: 0, romanticismo: 0, empatia: 0, creatividad: 0, valentia: 1 }
            },
            {
              id: 'exposicion-equipo',
              label: 'Firmar el préstamo de un mes',
              description: 'Convertid la recuperación en una exposición autorizada sobre Elvira, con devolución prevista.',
              next: 'ultima_luz',
              effects: { inteligencia: 0, perspicacia: 2, romanticismo: 0, empatia: 0, creatividad: 1, valentia: 0 }
            }
          ]
        }
      },
      endings: {
        promesa_devuelta: {
          id: 'promesa_devuelta',
          title: 'Una promesa devuelta',
          subtitle: 'Final · La historia vuelve a casa',
          tone: 'intimo',
          text: [
            'A las 23:41, Elena firma la entrega y coloca el colgante junto a la carta. Sale del Bellamar sin fotógrafos. Por primera vez en años, los dos objetos vuelven a estar en la misma casa.',
            'El lote se retira de la subasta. El hotel conserva el acta de devolución. Damián pierde la oportunidad de vender la Luna, pero esta noche no se abre una reclamación formal sobre su manipulación.',
            'La última luz de la habitación 309 se apaga. Vuestro expediente termina con una recuperación privada: no todo lo que puede convertirse en noticia necesita hacerlo.'
          ],
          explanation: 'El depósito original y la adjudicación acreditaban la propiedad de Elena. Vera retiró la Luna con su autorización y la custodió en recepción. Al elegir la devolución inmediata, la pieza y la carta salen con Elena esa misma noche. La decisión protege su intimidad y cierra la custodia, pero no activa la revisión formal de la conducta de Damián.',
          reflection: 'Elegisteis que el cierre perteneciera a su propietaria. ¿Cambiaríais esa prioridad si tuvierais otra noche para investigar?',
          romanticCoda: 'En vuestra ruta de cercanía, Alex y Noa se despiden con un café pendiente. La historia deja ese encuentro abierto.',
          professionalCoda: 'En vuestra ruta profesional, Alex y Noa firman el informe como equipo y acuerdan revisar juntos su siguiente encargo.'
        },
        buen_recaudo: {
          id: 'buen_recaudo',
          title: 'La próxima canción',
          subtitle: 'Final · El recuerdo se convierte en una beca',
          tone: 'sereno',
          text: [
            'Elena firma el acuerdo con la escuela de música. La Luna sale del hotel bajo custodia documentada; la carta vuelve a casa. Semanas después, Elena aprueba una venta benéfica independiente y el colgante pasa a una nueva propietaria.',
            'Con el dinero se crea la beca Elvira Soler. En su primer recital, una estudiante toca una pieza que Elvira interpretaba en el Bellamar. Elena escucha desde la segunda fila, con la carta guardada en el bolso.',
            'El objeto no regresó al joyero familiar ni acabó en una exposición. Se convirtió en tiempo de estudio y música para otra persona. Esta ruta no inició una reclamación formal contra Damián; dio al legado un destino elegido por Elena.'
          ],
          explanation: 'Elena era la propietaria y había autorizado explorar una venta benéfica futura. La escuela ofreció custodia y un destino concreto para los fondos; la firma final de Elena convirtió esa opción en una decisión suya. La diferencia con la maniobra del hotel es el consentimiento y la trazabilidad. Elegisteis transformar el objeto en una beca sin entregar la carta personal.',
          reflection: 'Elegisteis que el recuerdo cambiara de forma. ¿Qué conservaríais de una historia si no pudierais conservar su objeto?',
          romanticCoda: 'En vuestra ruta de cercanía, Alex y Noa llegan juntos al recital. Por una vez, lo único que tienen que hacer es escuchar.',
          professionalCoda: 'En vuestra ruta profesional, Alex y Noa documentan el cierre del acuerdo y la primera beca. Su informe termina donde empieza otra historia.'
        },
        subasta_cancelada: {
          id: 'subasta_cancelada',
          title: 'El lote que no se vendió',
          subtitle: 'Final · La alteración queda documentada',
          tone: 'firme',
          text: [
            'La subastadora incorpora al expediente el depósito de 2006, la factura del reloj y el historial de cambios. El lote de la Luna queda cancelado. Los demás se revisarán antes de seguir adelante.',
            'Damián es apartado de la gestión del catálogo mientras se investiga. La joya permanece temporalmente custodiada, con Elena reconocida como propietaria. El siguiente paso dependerá de esa revisión; vuestra noche no dicta una condena.',
            'Vera deja de figurar como sospechosa de una sustracción sin permiso. La carta no entra en el expediente: una historia íntima no era necesaria para demostrar la alteración.'
          ],
          explanation: 'La factura citada por Damián identificaba un reloj, y el historial mostraba quién la vinculó a la Luna y cambió su titularidad. Esas pruebas permitieron impugnar el lote y abrir una revisión sin divulgar la carta. Elegisteis exigir responsabilidades, aceptando que la devolución definitiva no se completara esa noche.',
          reflection: 'Elegisteis documentar el abuso aunque el cierre tardara más. ¿Qué parte del expediente os pareció imprescindible para hacerlo de forma justa?',
          romanticCoda: 'En vuestra ruta de cercanía, Alex y Noa salen al mirador cuando termina el acta. Esta vez no necesitan hablar de la investigación.',
          professionalCoda: 'En vuestra ruta profesional, Alex y Noa entregan un informe conjunto que separa los hechos acreditados de las consecuencias todavía pendientes.'
        },
        ultima_luz: {
          id: 'ultima_luz',
          title: 'La última luz del Bellamar',
          subtitle: 'Final · Un legado prestado, no vendido',
          tone: 'luminoso',
          text: [
            'Un mes después, la Luna se exhibe en el archivo municipal junto a fotografías del piano del Bellamar. La cartela dice: «Propiedad de Elena Soler. Préstamo temporal». La entrada es gratuita.',
            'Elena ha elegido qué recuerdos compartir. La carta permanece en casa. No forma parte de la exposición ni de su promoción. Al terminar el mes, el archivo devuelve el colgante según el acuerdo firmado.',
            'La subasta perdió su joya más vistosa y la ciudad ganó una pequeña historia sobre su música. Esta ruta no abrió esa noche la reclamación formal sobre Damián: priorizó recuperar y compartir el legado en las condiciones de Elena.'
          ],
          explanation: 'La propiedad y el permiso de custodia estaban acreditados. El préstamo escrito añadió límites concretos: un mes, inventario, seguro, reconocimiento de Elena y devolución. Elegisteis una consecuencia pública sin convertir la joya en mercancía ni la carta en espectáculo. No equivale a una resolución sobre la responsabilidad de Damián.',
          reflection: 'Elegisteis compartir una parte de la historia y reservar otra. ¿Dónde situaríais vosotros ese límite?',
          romanticCoda: 'En vuestra ruta de cercanía, Alex y Noa visitan la exposición sin llevar un cuaderno de investigación. Al salir, eligen su siguiente café.',
          professionalCoda: 'En vuestra ruta profesional, Alex y Noa comprueban la cartela y la devolución acordada. Su último trabajo fue dar a cada documento el alcance que le correspondía.'
        }
      }
    }
  ];

  // Server-compatible view. Terminal nodes live beside playable nodes here;
  // the browser-facing STORIES view retains a separate endings collection.
  const CASES = Object.fromEntries(STORIES.map(function (story) {
    const nodes = Object.fromEntries(Object.entries(story.nodes).map(function (entry) {
      const id = entry[0];
      const node = entry[1];
      return [id, Object.assign({}, node, {
        terminal: false,
        choices: node.choices.map(function (choice) {
          return Object.assign({}, choice, { nextNodeId: choice.next, score: Object.assign({}, choice.effects) });
        })
      })];
    }));
    Object.entries(story.endings).forEach(function (entry) {
      nodes[entry[0]] = Object.assign({}, entry[1], { terminal: true, choices: [] });
    });
    return [story.id, Object.assign({}, story, { startNodeId: story.startNode, nodes: nodes })];
  }));

  root.STORIES = STORIES;
  root.CASES = CASES;
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { STORIES: STORIES, CASES: CASES };
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
